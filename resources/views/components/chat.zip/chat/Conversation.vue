<template>
    <div class="flex flex-col h-full">
        <Header :title="conversationTitle" />

        <ChatArea
            :current-user="currentUser"
            :active-conversation="activeConversation"
            @send-message="sendMessage"
        />
    </div>
</template>

<script>
    import { defineComponent, computed } from 'vue';
    import { useRoute } from 'vue-router';
    import Header from './Header.vue';
    import ChatArea from './ChatArea.vue';
    import ConversationList from './ConversationList.vue';


    export default defineComponent({
        components: {
            Header,
            ChatArea,
        },
        props: ['currentUser', 'activeConversation'],
        emits: ['send-message'],
        setup(props, { emit }) {
            const route = useRoute();

            const conversationTitle = computed(() => {
                return props.activeConversation?.receiver?.name || 'Chat';
            });

            const sendMessage = (message) => {
                emit('send-message', message);
            };

            return {
                conversationTitle,
                sendMessage,
            };
        },
    });
</script>

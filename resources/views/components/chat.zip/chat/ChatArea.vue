<template>
    <div class="bg-gray-900 text-white flex-1 p-4 flex flex-col justify-between">
        <div>
            <div class="flex items-center mb-4">
                <div class="rounded-full w-10 h-10 flex items-center justify-center bg-blue-700 text-white mr-3">
                    {{ activeConversation.receiver.name.charAt(0) }}
                </div>
                <div>
                    <h3 class="font-semibold">{{ activeConversation.receiver.name }}</h3>
                    <p class="text-sm text-gray-400">Active {{ activeConversation.lastActive }}</p>
                </div>
            </div>

            <div class="overflow-y-auto">
                <div
                    v-for="message in activeConversation.messages"
                    :key="message.id"
                    class="mb-4"
                >
                    <div
                        class="flex items-start"
                        :class="{ 'justify-end': message.sender_id === currentUser.id }"
                    >
                        <div
                            v-if="message.sender_id !== currentUser.id"
                            class="rounded-full w-8 h-8 flex items-center justify-center bg-blue-700 text-white mr-3"
                        >
                            {{ message.sender ? message.sender.name.charAt(0) : activeConversation.receiver.name.charAt(0) }}
                        </div>
                        <div
                            :class="message.sender_id === currentUser.id ? 'bg-blue-600' : 'bg-gray-800'"
                            class="p-3 rounded-lg"
                        >
                            <p>{{ message.text }}</p>
                            <span class="text-xs text-gray-400">{{ formatTime(message.created_at) }}</span>
                        </div>
                        <div
                            v-if="message.sender_id === currentUser.id"
                            class="rounded-full w-8 h-8 flex items-center justify-center bg-blue-700 text-white ml-3"
                        >
                            {{ currentUser.name.charAt(0) }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <form @submit.prevent="sendMessage" class="flex items-center p-3 bg-gray-800 rounded-lg">
            <button type="button" class="text-gray-400 hover:text-white mr-3">
                <i class="fas fa-camera"></i>
            </button>
            <button type="button" class="text-gray-400 hover:text-white mr-3">
                <i class="fas fa-paperclip"></i>
            </button>
            <input
                v-model="newMessage"
                type="text"
                class="flex-1 bg-gray-700 text-white p-2 rounded-lg focus:outline-none"
                placeholder="Type a message"
            />
            <button type="submit" class="text-blue-500 hover:text-blue-600 ml-3">
                <i class="fas fa-paper-plane"></i>
            </button>
        </form>
    </div>
</template>

<script>
    import { defineComponent, ref } from 'vue';

    export default defineComponent({
        name: 'ChatArea',
        props: {
            currentUser: {
                type: Object,
                required: true
            },
            activeConversation: {
                type: Object,
                required: true
            }
        },
        emits: ['send-message'],
        setup(props, { emit }) {
            const newMessage = ref('');

            const formatTime = (date) => {
                const options = { hour: '2-digit', minute: '2-digit' };
                return new Date(date).toLocaleTimeString([], options);
            };

            const sendMessage = () => {
                if (newMessage.value.trim()) {
                    emit('send-message', newMessage.value);
                    newMessage.value = '';
                }
            };

            return {
                newMessage,
                formatTime,
                sendMessage
            };
        }
    });
</script>

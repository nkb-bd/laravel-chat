<template>
    <div class="flex flex-col h-full">
        <Header title="Chat Rooms" />
        <div class="flex-1 overflow-y-auto">
            <ConversationList
                :conversations="conversations"
                @select-conversation="selectConversation"
            />
        </div>
    </div>
</template>

<script>
    import { defineComponent } from 'vue';
    import { useRouter } from 'vue-router';
    import Header from './Header.vue';
    import ConversationList from './ConversationList.vue';

    export default defineComponent({
        components: {
            Header,
            ConversationList,
        },
        props: ['conversations'],
        setup(props, { emit }) {
            const router = useRouter();

            const selectConversation = (conversationId) => {
                emit('select-conversation', conversationId);
                router.push({ name: 'conversation', params: { id: conversationId } });
            };

            return {
                selectConversation,
            };
        },
    });
</script>
